from django.shortcuts import render
from django.http import JsonResponse

def index(request):
    return render(request, 'game/index.html')

def update_grid(request):
    if request.method == 'POST':
        grid = request.POST.get('grid')
        grid = [[int(cell) for cell in row.split(',')] for row in grid.split(';')]

        new_grid = []
        rows, cols = len(grid), len(grid[0])
        for i in range(rows):
            new_row = []
            for j in range(cols):
                neighbors = sum([
                    grid[i-1][j] if i-1 >= 0 else 0,
                    grid[i+1][j] if i+1 < rows else 0,
                    grid[i][j-1] if j-1 >= 0 else 0,
                    grid[i][j+1] if j+1 < cols else 0,
                    grid[i-1][j-1] if i-1 >= 0 and j-1 >= 0 else 0,
                    grid[i-1][j+1] if i-1 >= 0 and j+1 < cols else 0,
                    grid[i+1][j-1] if i+1 < rows and j-1 >= 0 else 0,
                    grid[i+1][j+1] if i+1 < rows and j+1 < cols else 0
                ])
                if grid[i][j] == 1 and neighbors not in [2, 3]:
                    new_row.append(0)
                elif grid[i][j] == 0 and neighbors == 3:
                    new_row.append(1)
                else:
                    new_row.append(grid[i][j])
            new_grid.append(new_row)

        return JsonResponse({'grid': new_grid})
    return JsonResponse({'error': 'Invalid request'}, status=400)
